
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from app.routes import stocks, funds, insights

app = FastAPI(
    title="FinGenius API",
    description="AI-powered stock and fund recommendations backend",
    version="1.0.0"
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(stocks.router, prefix="/stocks")
app.include_router(funds.router, prefix="/funds")
app.include_router(insights.router, prefix="/insights")
