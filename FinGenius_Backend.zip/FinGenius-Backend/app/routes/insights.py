
from fastapi import APIRouter

router = APIRouter()

@router.get("/hold-strategy")
def hold_strategy():
    return {
        "strategy": "Hold top-performing large caps for at least 6 months to maximize profit with low volatility."
    }
