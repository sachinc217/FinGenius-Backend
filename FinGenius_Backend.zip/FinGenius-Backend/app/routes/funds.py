
from fastapi import APIRouter

router = APIRouter()

@router.get("/best")
def get_best_mutual_funds():
    return [
        {"name": "Axis Bluechip Fund", "risk": "Moderate", "return": "18%", "duration": "5Y"},
        {"name": "Mirae Asset Tax Saver", "risk": "Low", "return": "16%", "duration": "3Y"},
        {"name": "ICICI Tech Fund", "risk": "High", "return": "24%", "duration": "1Y"},
    ]
