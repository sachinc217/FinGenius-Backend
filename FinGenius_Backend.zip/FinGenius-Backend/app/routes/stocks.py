
from fastapi import APIRouter
from typing import List
import random

router = APIRouter()

@router.get("/recommendations")
def get_recommendations():
    stocks = ["AAPL", "GOOGL", "TSLA", "MSFT", "AMZN"]
    return [
        {
            "symbol": stock,
            "recommendation": random.choice(["Buy", "Sell", "Hold"]),
            "entry_price": f"${round(random.uniform(100, 300), 2)}",
            "hold_duration": random.choice(["1 month", "3 months", "6+ months"])
        } for stock in stocks
    ]
